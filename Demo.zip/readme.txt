Instructions:

In order to start the tractor you should:

1. Hit the button on the control platform by pressing B.
2. Start the engine by pressing G.
3. Switch gear by pressing 2, 4, 6 or 8 on numpad.
(in any order)

With W, A, S, D or arrow keys you can drive the tractor.
L lifts the plower up and K down.
H stops the engine.
1, 2 and 3 switches between seat, back and front camera. Seat view provides free camera look with mouse.
SPACE can be used for brake.